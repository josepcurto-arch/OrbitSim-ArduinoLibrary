#include "OrbitSim.h"

// Variables
unsigned long nextUpdate;
double real_orbital_period;
double r;

// Last calculated position stored as static array
static double pos[3];

void orbitSetup() {
    Serial.begin(9600);
    nextUpdate = MILLIS_BETWEEN_UPDATES;
    
    r = R_EARTH + ALTITUDE;
    real_orbital_period = 2 * PI * sqrt(pow(r, 3) / (G * M));
}

double* orbitLoop() {
    unsigned long currentTime = millis();
    if (currentTime > nextUpdate) {
        nextUpdate = currentTime + MILLIS_BETWEEN_UPDATES;
        return simulate_orbit(currentTime);
    }
    // If no update, return last position
    return pos;
}

double* simulate_orbit(unsigned long millis, double inclination, int ecef) {
    double time = (millis / 1000.0) * TIME_COMPRESSION;
    double angle = 2 * PI * (time / real_orbital_period);

    double x = r * cos(angle);
    double y = r * sin(angle) * cos(inclination);
    double z = r * sin(angle) * sin(inclination);

    if (ecef) {
        double theta = EARTH_ROTATION_RATE * time;
        double x_ecef = x * cos(theta) - y * sin(theta);
        double y_ecef = x * sin(theta) + y * cos(theta);
        x = x_ecef;
        y = y_ecef;
    }

    // Save position in static array
    pos[0] = x;
    pos[1] = y;
    pos[2] = z;

    return pos;
}
