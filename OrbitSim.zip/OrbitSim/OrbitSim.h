#ifndef ORBITSIM_H
#define ORBITSIM_H

#include <Arduino.h>

// Constants
const double G = 6.67430e-11;
const double M = 5.97219e24;
const double R_EARTH = 6371000;
const double ALTITUDE = 400000;
const double EARTH_ROTATION_RATE = 7.2921159e-5;
const unsigned long MILLIS_BETWEEN_UPDATES = 1000;
const double TIME_COMPRESSION = 90.0;

// Variables
extern unsigned long nextUpdate;
extern double real_orbital_period;
extern double r;

// Functions
void orbitSetup();
double* orbitLoop();  // returns array of 3 doubles: [x, y, z]
double* simulate_orbit(unsigned long millis, double inclination = 0, int ecef = 0);

#endif


